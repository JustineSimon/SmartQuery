<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
    
$servername = "sql312.ezyro.com";
$username = "ezyro_40253790";   // default profreehost MySQL user
$password = "11e6036f2413de8";       // default profreehost password
$dbname = "ezyro_40253790_smartquery_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
